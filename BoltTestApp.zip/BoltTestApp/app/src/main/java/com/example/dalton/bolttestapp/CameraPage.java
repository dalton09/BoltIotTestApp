 package com.example.dalton.bolttestapp;

        import android.content.Intent;
        import android.content.pm.PackageManager;
        import android.database.Cursor;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.net.Uri;
        import android.os.Environment;
        import android.provider.MediaStore;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.ImageView;
        import android.widget.Toast;

        import java.io.File;
        import java.io.FileInputStream;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.net.URI;
        import java.nio.channels.FileChannel;
        import java.text.SimpleDateFormat;
        import java.util.Date;

public class CameraPage extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 0; //way to identify the intent. this is to open the camera
    ImageView imgview;
    private File imageFolder;
    private File imageFile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_page);
        Button click = (Button) findViewById(R.id.click);
        imgview = (ImageView) findViewById(R.id.imageView);

        //Disable btn if no cam

        if (!hasCamera())
            click.setEnabled(false);

        click.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
            }
            //launch cam
        });
    }

    //check for cam

    private boolean hasCamera() {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }


    //return img taken
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap photo = (Bitmap) extras.get("data");
            imgview.setImageBitmap(photo);
            startActivity(new Intent(this, Form.class));
        }




    }

}