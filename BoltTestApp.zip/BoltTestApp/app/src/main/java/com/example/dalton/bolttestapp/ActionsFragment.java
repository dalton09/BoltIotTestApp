package com.example.dalton.bolttestapp;


import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;

import static com.example.dalton.bolttestapp.R.layout.fragment_actions;


/**
 * A simple {@link Fragment} subclass.
 */
public class ActionsFragment extends Fragment {

    Button btn;

    public ActionsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(fragment_actions, container, false);
        btn = (Button) view.findViewById(R.id.open_cam);


        btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                Intent i= new Intent(getActivity(), CameraPage.class);
                startActivity(i);
            }
        });


        return view;

    }

}
